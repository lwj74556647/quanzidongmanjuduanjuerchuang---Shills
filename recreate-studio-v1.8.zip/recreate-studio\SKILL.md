﻿---
name: recreate-studio
description: 当用户要"下载素材后直接出片""把素材自动剪成二创视频""挑高燃片段混剪""封面做片头""批量做抖音二创/短剧推广视频""自动加水印/BGM/特效"或"切成 3 分钟成片"时使用。整合素材下载（登录站抓取 / 百度网盘 / 直链）与全自动剪辑（FFmpeg + BGM 库）：2.5 秒封面片头 + 按音频能量/画面运动挑高燃片段，默认不加解说旁白，产出指定比例、约 180 秒、带水印/BGM/特效的成片，并按素材名归入对应文件夹。
---

# Recreate Studio（下载 + 二创成片 一体化）

两个阶段串成一条全自动链路：

```
阶段 0  素材获取  →  阶段 1 素材检查  →  阶段 2 全自动二创  →  阶段 3 校验交付
（asset-harvester）                       （本技能核心）
```

## 〇、能力与默认值

- **下载**：登录态网站（Playwright 接管 Chrome，抓接口）→ 百度网盘分享（BaiduPCS-Go）→ 只下点名文件（如封面 + 1/2/3 集）→ 按内容名建文件夹。
- **剪辑**：每部剧自动出 1 条约 **180 秒**成片，落到**该剧自己的文件夹**里。
- **画面**：默认 **9:16（1080×1920，抖音主流竖屏）**，可选 `16:9`/`1:1`/`19:6`/`WxH`。
  `19:6`（1920×608）为超宽画布，竖屏素材两侧会大面积虚化，仅特殊需求时使用。
- **片头**：默认用素材里的封面图做 **2.5 秒片头**（铺满画布 + 缓慢推近），随后接高燃混剪；`--no-cover` 可关闭。
- **选段**：默认按「音频能量 0.6 + 画面运动 0.4」从三集里挑 18 个高燃窗口，按强度由弱到强排布（不是随机平铺）。
- **加工**：多段混剪、调色、暗角、颗粒、变速、按情绪选 BGM 并侧链闪避、半透明水印。
  **默认不加解说旁白、不加额外字幕**（保留源片自带字幕）；需要解说时加 `--tts`，会同时生成 TTS 与逐句字幕。
  `--mirror` 可选隔段镜像（默认关闭，源片硬字幕会被镜像成反字）。
- **输出**：`<剧文件夹>\<剧名>_二创_3min.mp4` + `<剧名>_二创_报告.json`。
  已存在同名成片默认跳过（`--force` 覆盖）。
- **批量**：`--root <LIBRARY_ROOT>` 自动遍历所有含 `1.mp4` 的文件夹。

## 一、阶段 0：素材获取（复用 asset-harvester）

**触发**：用户要下载素材；或阶段 1 检查发现素材缺失。

流程与坑点见 `asset-harvester` 技能（`~/.dsh/skills/asset-harvester/SKILL.md`），要点：

1. 已登录网站 → Playwright 连 Chrome 副本（`--user-data-dir=D:\chrome-dsh-profile --remote-debugging-port=9333`）→ 抓列表/详情接口拿下载地址；接口签名由页面完成，不要页面外重放。
2. 百度网盘分享 → `BaiduPCS-Go transfer <链接> <pwd>` → `download --saveto "<剧文件夹>" -p 8 封面.jpg 1.mp4 2.mp4 3.mp4`。
3. 只下点名文件（封面 + 前几集），不整包。
4. 目录：`<根>\NNN. <剧名>`；命名容错：`：共N集` 后缀、套层目录、`封面/`+`正片/` 结构、封面名 `cover (n).jpg`。
5. 下载稳定性：GBK 解码、`stdout=DEVNULL` 防管道死锁、断点续跑。

精简命令见 `references/download-stage.md`。

## 二、阶段 1：素材检查

每个待加工文件夹至少需要：

- `1.mp4`、`2.mp4`、`3.mp4`（没有第 3 集就跳过或改用 1/2）
- 可选 `封面.jpg`（不参与成片，仅归档）

缺素材 → 回到阶段 0 补齐，不要用占位素材硬剪。

## 三、阶段 2：全自动二创（核心）

```powershell
$py = "C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
& $py "<SKILLS_DIR>\recreate-studio\scripts\recreate.py" `
  --folder "<LIBRARY_ROOT>\001. 毒酒换红妆" `
  --aspect 9:16 --duration 180 --watermark "@你的账号名"
```

批量：

```powershell
& $py "...\recreate.py" --root "<LIBRARY_ROOT>" --aspect 9:16 --watermark "@账号名" --limit 5
```

常用参数：

| 参数 | 说明 |
|---|---|
| `--folder` / `--root` | 单部 / 批量根目录 |
| `--aspect` | `9:16`（默认）/`16:9`/`1:1`/`19:6`/`WxH` |
| `--duration` | 目标秒数，默认 180 |
| `--watermark` | 水印文案，建议 `@账号名` |
| `--voice` | edge-tts 音色，默认 `zh-CN-YunxiNeural`（男声解说） |
| `--tts` | 开启 AI 解说旁白 + 逐句字幕（默认关闭） |
| `--suffix` | 输出文件名后缀，便于 A/B（如 `_9x16`） |
| `--no-cover` | 不用封面做片头（默认 2.5s 封面片头） |
| `--force` | 覆盖已有成片 |

处理流程（脚本内部）：

1. `ffprobe` 读取三集宽高/时长/音轨；**只使用带原声的素材**（原声必须像字幕一样保留进成片）。
2. **高燃选段（按完整台词句下刀）**：优先 `faster-whisper` 句级时间戳（缓存 `<clip>.asr.json`），窗口由连续完整句组成；ASR 不可用时只用 `silencedetect` 静音中点，**禁用镜头切换点**（会切进句子）。窗口 8–12s，再按音频能量 0.6 + 画面运动 0.4 打分排序，取约 18–20 段、由弱到强。**禁止切断人物语音句子**。
3. 每段单独渲染：模糊背景铺满画布 + 前景等比缩放居中 + 调色 + 暗角 + 颗粒 + 30fps（镜像默认关闭）；**默认不额外烧字幕**，保留源片自带硬字幕（画面干净、与语音天然同步）；`--subtitles` 是实验选项（会与源字幕重影，需配合字幕条/裁切）。
4. concat 拼接时间线（音画同步）；原声保持 1.0 为主轨，BGM 0.12 并由原声侧链闪避。
5. 按剧名关键词选 BGM 情绪（悬疑/紧张/悲伤/温柔/激昂/空灵/轻快），循环到 180s。
6. 终混（默认无解说）：**原声 1.0 全音量** + BGM 0.12，BGM 由原声侧链闪避；若加 `--tts` 则解说 1.0 + 原声 0.7 + BGM 0.12。
7. 叠加水印；输出 H.264 CRF19 + AAC 192k + `faststart`，写报告 JSON（含高燃分数）。

细节参数与滤镜链：`references/editing-recipe.md`。

## 四、阶段 3：校验与交付

必须全绿：

- [ ] 成片时长 175–185 秒
- [ ] 分辨率等于目标比例（如 19:6 → 1920×608；9:16 → 1080×1920）
- [ ] 有音轨；**原声保留**（报告 `original_audio=true`，且只用带音轨素材）
- [ ] **音画同步**：成片视频时长与音频时长差 < 0.1s；变速段抽检 300 帧=10.000s、音频 10.000s
- [ ] **切点完整**：报告 `cut_aligned=true`，段长 8–12s，抽听段落开头/结尾无半句台词
- [ ] 报告里 `compliance`：多段/特效/水印/BGM 为 true；未加解说时 `commentary`/`subtitles` 应为 false 且 `tts="disabled"`；`highlight_scores` 非空
- [ ] 成片位于**对应剧文件夹**内

报告字段示例（默认高燃剪辑、无解说）：

```json
{"duration":180.0,"size":"1080x1920","watermark":"@账号",
 "bgm":"悬疑","segments":18,"clips":3,
 "cover_file":"封面.jpg","cover_intro":true,
 "highlight":true,"highlight_scores":[0.42,0.55,0.61],
 "tts":"disabled","narration_chars":0,
 "compliance":{"multi_clip":true,"effects":true,"mirror":false,
               "watermark":true,"commentary":false,"subtitles":false,"bgm":true}}
```

## 五、抖音二创审核（重要，但不承诺必过）

审核要点与发布话术见 `references/compliance-douyin.md`。核心：

1. **强加工**：多段混剪 + 转场 + 调色 + 镜像 + 变速 + 解说 + 字幕 + BGM + 水印，避免"纯搬运/超简解说"。
2. **二创声明**：发布时写明二创/解说性质；含 AI 合成内容（TTS/AI 生成）时按抖音要求勾选「内容由AI生成」。
3. **版权**：只处理自己账号、已获授权或平台允许推广的素材；不碰盗版/付费墙内容。
4. **风险**：审核含机器+人工，无法保证 100% 过审；被限流时更换解说/画面节奏/水印位置后重投。

## 六、Windows 一键批处理（双击可用）

`scripts/一键二创_碧海剧场.bat`（同目录 `wm.ps1` 生成 UTF-8 水印文本，供纯 FFmpeg 模式使用）：

```
一键二创.bat                          处理 <LIBRARY_ROOT>
一键二创.bat "D:\素材库" 1            只跑前 1 部试水
一键二创.bat "D:\素材库" 0 force      已存在也重剪
一键二创.bat "D:\素材库" 0 force pure 无 Python 时强制纯 FFmpeg 模式
```

- 默认：9:16、水印“碧海剧场”、180s、按剧名关键词自动配 BGM、特效、成品写回各自素材文件夹
- 完整模式（默认）：高燃选段 + 封面片头 + 音画同步
- `pure` 模式：3 段 × 60s + 特效 + 水印 + BGM（无高燃评分，保底可用）
- 日志：`<素材根>\_二创日志.txt`

## 七、环境与依赖

- FFmpeg / ffprobe：`<FFMPEG_DIR>\ffmpeg.exe`（可用环境变量 `RECREATE_FFMPEG` 覆盖）
- Python：DSH 自带；`pip install edge-tts playwright`
- BGM：按顺序解析 `RECREATE_BGM_DIR` → 桌面 `漫剧短剧BGM库` → 旧 studio 目录 → 技能 `assets/bgm`；
  目录为空时，`recreate.py` 内置的 39 首来源清单会自动从 Mixkit（免署名）/ Incompetech（CC-BY）下载，并生成 10 分类 + `index.json` 情绪映射。
  单独准备 BGM：`python recreate.py --setup-bgm`（可加 `--bgm-limit 2` 试跑）。
- 字体：`C:\Windows\Fonts\msyh.ttc`

## 八、来源 / 版本 / 回滚

- 版本：v1.8（2026-10-26）：**单文件**——BGM 来源清单与下载逻辑内嵌进 `recreate.py`，删除独立 `bgm_setup.py`；首次运行自动补齐 BGM。
- v1.6：字幕策略（默认保留源字幕、不额外烧）、原声 1.0 全保留、ASR 句级切点、水印右上角。
- v1.4：切点改为“台词完整处”——silencedetect 静音中点 + 镜头切换点，候选窗口两端锚定切点，避免切断句子。
- v1.3：修复变速下的音画同步——变速作用于整段（背景+前景），每段强制 300 帧/10.000s + 音频 apad/atrim 等长，concat 音频重编码，去掉会引入延迟的 loudnorm。
- v1.2：新增 2.5s 封面片头（`--no-cover` 可关）；高燃选段（音频能量 0.6 + 画面运动 0.4）；默认关闭解说旁白与字幕；镜像默认关闭（源片硬字幕会反）。
- 来源：星图 112 部短剧素材实战 + 19:6/9:16 实测 + 高燃选段与封面片头实测
- 合并说明：原「下载」技能 asset-harvester 已并入本技能（阶段 0），独立目录已删除
- 回滚：`Remove-Item -Recurse <SKILLS_DIR>\recreate-studio` + `memory remove`
- 更新：按全局版本规则升级并同步记忆库
